# This is a sample Python script.

# Press Shift+F10 to execute it or replace it with your code.
# Press Double Shift to search everywhere for classes, files, tool windows, actions, and settings.


# Press the green button in the gutter to run the script.
import csv

import pandas as pd

if __name__ == '__main__':
    path_input1 = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/NetflixOriginals.csv")
    path_input2 = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/titles.csv")
    path_output = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/TitleFinale.csv")

    netflix = pd.read_csv(path_input1, encoding="ISO-8859-1")
    netflix.head()

    titles = pd.read_csv(path_input2, encoding="ISO-8859-1")
    titles.head()
    # for r2 in netflix:
    #     file2 = pd.DataFrame(titles)
    #     print(file2)

    merged_data = pd.merge(netflix,titles, left_on= "Title", right_on="Title", how="inner")
    merged_data.head()
    data=pd.DataFrame(merged_data)
    merged_data_clean = merged_data.fillna(0)
    print("file nuovo", merged_data_clean)
    merged_data_clean.to_csv(path_output,index=False)




