
import pandas as pd

path_input_titles = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/TitleFinale.csv")
path_output_titles = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/TitleTotalClean.csv")
path_input_credits = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/CreditsClean.csv")
path_output_credits = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/CreditsTotalClean.csv")


titles = pd.read_csv(path_input_titles, encoding="ISO-8859-1")
titles.head()
titlesDeleteColum = titles.iloc[:, 0:14]
titlesDeleteColum.to_csv(path_output_titles,index=False)

credits = pd.read_csv(path_input_credits)
credits.head()
creditsDeleteEmpty = credits.fillna("Other")
creditsDeleteColum = creditsDeleteEmpty.iloc[:, 14:]
creditsDeleteColum.to_csv(path_output_credits,index=False)