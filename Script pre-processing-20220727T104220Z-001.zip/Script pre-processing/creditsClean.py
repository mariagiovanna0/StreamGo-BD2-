import pandas as pd

path_input1 = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/TitleTotalClean.csv")
path_input2 = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/credits.csv")
path_output = ("C:/Users/ASUS/Desktop/UNISA/BD2/progetto/io/dataset/film/CreditsClean.csv")

titleTotalClean = pd.read_csv(path_input1)
titleTotalClean.head()

credits = pd.read_csv(path_input2)
credits.head()
merged_data = pd.merge(titleTotalClean,credits, left_on= "id", right_on="id", how="inner")
merged_data.to_csv(path_output, index=False)